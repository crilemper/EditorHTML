﻿using System;
using System.Drawing;
using System.Windows.Forms;
using FastColoredTextBoxNS;
using System.Drawing.Drawing2D;

namespace Tester
{
    public partial class RulerSample : Form
    {
        public RulerSample()
        {
            InitializeComponent();
        }
    }
}
