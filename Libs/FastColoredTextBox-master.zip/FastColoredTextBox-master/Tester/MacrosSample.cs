﻿using System;
using System.Windows.Forms;
using FastColoredTextBoxNS;

namespace Tester
{
    public partial class MacrosSample : Form
    {
        public MacrosSample()
        {
            InitializeComponent();   
        }
    }
}
